# aptoide-client
For translation contributions please go to http://translate.aptoide.com
Thank you.
The Aptoide Team
