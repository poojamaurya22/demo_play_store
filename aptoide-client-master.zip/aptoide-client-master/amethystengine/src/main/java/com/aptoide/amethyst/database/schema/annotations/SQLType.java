package com.aptoide.amethyst.database.schema.annotations;

/**
 * Created with IntelliJ IDEA.
 * User: brutus
 * Date: 07-10-2013
 * Time: 12:08
 * To change this template use File | Settings | File Templates.
 */
public enum SQLType {
    INTEGER, TEXT, FLOAT, DATE, REAL, BOOLEAN
}


