package com.aptoide.amethyst.downloadmanager.exception;

/**
 * Created with IntelliJ IDEA.
 * User: rmateus
 * Date: 05-07-2013
 * Time: 15:41
 * To change this template use File | Settings | File Templates.
 */
public class Md5FailedException extends Exception{
}
