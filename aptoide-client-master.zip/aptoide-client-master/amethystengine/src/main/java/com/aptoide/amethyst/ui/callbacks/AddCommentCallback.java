package com.aptoide.amethyst.ui.callbacks;

/**
 * Created by jcosta on 02-07-2014.
 */
public interface AddCommentCallback {
    void addComment(String comment, String answerTo);
}
