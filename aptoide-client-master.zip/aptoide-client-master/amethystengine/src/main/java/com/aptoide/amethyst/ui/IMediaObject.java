package com.aptoide.amethyst.ui;

/**
 * Created by tdeus on 2/12/14.
 */
public interface IMediaObject {

    String getImageUrl();

}
