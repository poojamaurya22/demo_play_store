package com.aptoide.amethyst.webservices.timeline.json;

/**
 * Created by fabio on 14-10-2015.
 */
public class Friend {
    public String getUsername() {
        return username;
    }
    public String getAvatar() {
        return avatar;
    }
    public String getEmail() {
        return email;
    }

    String username;
    String avatar;

    String email;
}
