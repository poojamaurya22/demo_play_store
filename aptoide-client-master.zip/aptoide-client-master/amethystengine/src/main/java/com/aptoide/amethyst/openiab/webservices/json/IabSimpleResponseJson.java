package com.aptoide.amethyst.openiab.webservices.json;


/**
 * Created by j-pac on 21-02-2014.
 */
public class IabSimpleResponseJson {


    public String status;



    public String getStatus() {
        return status;
    }



}
