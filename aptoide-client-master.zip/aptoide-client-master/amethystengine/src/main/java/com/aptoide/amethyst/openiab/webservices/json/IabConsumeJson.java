package com.aptoide.amethyst.openiab.webservices.json;


/**
 * Created by j-pac on 20-02-2014.
 */
public class IabConsumeJson {


    public String status;

    public String getStatus() {
        return status;
    }
}
