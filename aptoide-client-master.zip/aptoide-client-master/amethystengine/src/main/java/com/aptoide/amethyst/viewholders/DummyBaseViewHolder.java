package com.aptoide.amethyst.viewholders;

import android.view.View;

import com.aptoide.models.displayables.Displayable;

/**
 * Created by neuro on 24-02-2016.
 */
public class DummyBaseViewHolder extends BaseViewHolder {

	public DummyBaseViewHolder(View itemView, int viewType) {
		super(itemView, viewType);
	}

	@Override
	public void populateView(Displayable displayable) {

	}

	@Override
	protected void bindViews(View itemView) {

	}
}
