package com.aptoide.amethyst.adapters;

/**
 * Created by rmateus on 02/06/15.
 */
public interface SpannableRecyclerAdapter {


    public int getSpanSize(int position);

}
