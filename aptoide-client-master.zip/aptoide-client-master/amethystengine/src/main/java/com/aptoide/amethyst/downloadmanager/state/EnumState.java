package com.aptoide.amethyst.downloadmanager.state;

/**
 * Created with IntelliJ IDEA.
 * User: rmateus
 * Date: 05-07-2013
 * Time: 14:11
 * To change this template use File | Settings | File Templates.
 */
public enum EnumState {
    ACTIVE, COMPLETE, INACTIVE, PENDING , ERROR
}
