package com.aptoide.amethyst.webservices.model;

/**
 * Created by rmateus on 26-02-2014.
 */
public class ResponseCode {

    public int responseCode;


    @Override
    public int hashCode() {
        return 2;
    }
}
