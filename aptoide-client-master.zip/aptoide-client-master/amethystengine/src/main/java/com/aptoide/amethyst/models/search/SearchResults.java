package com.aptoide.amethyst.models.search;

import com.aptoide.models.displayables.SearchApk;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rmateus on 12/06/15.
 */
public class SearchResults {

    public List<SearchApk> apkList = new ArrayList<>();
    public List<SearchApk> uApkList = new ArrayList<>();
    public List<String> didyoumean = new ArrayList<>();

}
