package com.aptoide.amethyst.downloadmanager;

/**
 * Created by jcosta on 09-07-2014.
 */
public interface CompleteDownloadCallback {
    void onCompleteDownload(long id);
}
