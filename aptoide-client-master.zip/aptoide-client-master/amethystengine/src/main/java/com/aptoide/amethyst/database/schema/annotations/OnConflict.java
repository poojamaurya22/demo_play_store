package com.aptoide.amethyst.database.schema.annotations;

/**
 * Created with IntelliJ IDEA.
 * User: brutus
 * Date: 08-10-2013
 * Time: 13:11
 * To change this template use File | Settings | File Templates.
 */
public enum OnConflict {
    REPLACE, IGNORE, ABORT, NONE
}
