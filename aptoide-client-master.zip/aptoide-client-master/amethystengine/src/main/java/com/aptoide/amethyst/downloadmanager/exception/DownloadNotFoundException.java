package com.aptoide.amethyst.downloadmanager.exception;

/**
 * Created with IntelliJ IDEA.
 * User: rmateus
 * Date: 09-07-2013
 * Time: 11:27
 * To change this template use File | Settings | File Templates.
 */
public class DownloadNotFoundException extends Exception {
}
