package com.aptoide.amethyst.downloadmanager.exception;

/**
 * Created with IntelliJ IDEA.
 * User: rmateus
 * Date: 09-07-2013
 * Time: 11:30
 * To change this template use File | Settings | File Templates.
 */
public class IPBlackListedException extends Exception {
}
